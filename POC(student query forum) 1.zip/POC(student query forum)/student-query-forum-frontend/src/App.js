import { Route, Routes, useNavigate } from "react-router-dom";
import NavBar from "./headers/NavBar";
import SignIn from "./pages/Account/SignIn";
import SignUp from "./pages/Account/SignUp";
import StudentDashBoard from "./pages/student/StudentDashBoard";
import AddNewQuery from "./pages/student/AddNewQuery";
import TAsDashboard from "./pages/TAs/TAsDashboard";
import { CurrentUserContext } from "./lib/ContextAPI";
import { useEffect, useState } from "react";
import PrivateRoute from "./config/PrivateRoutes";
import { getData } from "./config/backendAPI";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css'
import PageNotFound from "./lib/components/PageNotFound";

function App() {
  const [currentUser, setCurrentUser] = useState(null)
  const updateCurrentUser = user => {
    setCurrentUser(user);
  }
  const navigate = useNavigate()
  useEffect(() => {
    const userId = localStorage.getItem('userId')
    if(userId)
      getData(`users/${userId}`)
      .then(res => {
        setCurrentUser(res.data)
        if(res.data.role === 'student')
          navigate('student')
        else 
          navigate('tas/queries')
        })
      .catch(error => console.log(error))
  },[])
  return (
    <CurrentUserContext.Provider value={{currentUser, updateCurrentUser}} >
      <div className="App">
        <ToastContainer />
        <NavBar />
        <Routes >
          <Route path="/" element = {<SignIn />} />
          <Route path="signup" element = {<SignUp />} />
          <Route element = {<PrivateRoute />}>
            <Route path="student" element = {<StudentDashBoard />} />
            <Route path="student/addQuery" element = {<AddNewQuery />} />
            <Route path="tas/queries" element = {<TAsDashboard />} />
          </Route>
          <Route path="*" element={<PageNotFound />} />
        </Routes >
      </div>
    </CurrentUserContext.Provider>
  );
}
export default App;
