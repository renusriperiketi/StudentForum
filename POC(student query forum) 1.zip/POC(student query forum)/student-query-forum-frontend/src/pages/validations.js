import { validateConfirmPassword, validateName, validateNumber, validatePassword, validateRollNumber, validateText } from "../utils/validaters"
import _ from "underscore";
const validateSignin = state => {
  let errors = {}
  const  rollNumber = validateRollNumber(state.rollNumber)
  const  password = validatePassword(state.password)
  
  if(rollNumber){
    errors['rollNumber'] = rollNumber
  }
  if(password){
    errors['password'] = password
  }
   
  if( _.isEmpty(errors) )
    return true;
  else 
    return errors;
}

const validateSignup = state => {
  let errors = {
  }
  const  name = validateName(state.name)
  const  rollNumber = validateRollNumber(state.rollNumber)
  const  password = validatePassword(state.password)
  const  confirmPassword = validateConfirmPassword(state.password, state.confirmPassword)
  if(name){
    errors['name'] = name
  } 
  if(rollNumber){
    errors['rollNumber'] = rollNumber
  }
  if(password){
    errors['password'] = password
  }
  if(confirmPassword){
    errors['confirmPassword'] = confirmPassword
  }
   
  if( _.isEmpty(errors) )
    return true;
  else 
    return errors;
}

const validateStudentQueryForm = state => {
  let errors = {
  }
  const  examName = validateName(state.examName) 
  const  courseName = validateName(state.courseName)
  const  questionNumber = validateNumber(state.questionNumber)
  const  taName = validateName(state.taName)
  const  comments = validateText(state.comments)
  if(examName){
    errors['examName'] = examName
  } 
  if(courseName){
    errors['courseName'] = courseName
  }
   if(questionNumber){
    errors['questionNumber'] = questionNumber
  }
   if(taName){
    errors['taName'] = taName
  }
   if(comments){
    errors['comments'] = comments
  }
  if(_.isEmpty(errors))
    return true 
  else 
    return errors
}

export {
  validateSignup,
  validateSignin,
  validateStudentQueryForm, 
}