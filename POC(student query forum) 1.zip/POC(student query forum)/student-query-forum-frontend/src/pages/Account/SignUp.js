import React, { useContext, useState } from 'react'
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router';
import { postData } from '../../config/backendAPI';
import { CurrentUserContext } from '../../lib/ContextAPI';
import Form from '../../lib/components/form/Form';
import SelectDrapdown from '../../lib/components/form/SelectDrapdown';
import TextInput from '../../lib/components/form/TextInput';
import Button from '../../lib/components/form/Button';
import {  validateSignup } from '../validations';
import '../../lib/assets/stylesheets/pages/account/SignIn.css'

const SignUp = () => {
  const initialState = {
    name: '',
    rollNumber: '',
    password: '',
    confirmPassword: '',
    role: 'student'
  }
  const roles = ['student', 'TA']
  const navigate = useNavigate();
  const { updateCurrentUser} = useContext(CurrentUserContext)
  const [data, setData] = useState(initialState);
  const [errors, setErrors] = useState({})
  
  const handleSignUp = event => {
    event.preventDefault();
    // let validationResponse = validateSignup(data)
    // if(validationResponse === true)
    {
      const userData = {
        full_name: data.name,
        roll_number: data.rollNumber,
        password: data.password,
        password_confirmation: data.confirmPassword,
        role: data.role,
      }
      const URL = 'users'
      postData(URL, userData)
      .then(res => {
        if(res.data.status === 409){
          setErrors({rollNumber: "Roll number Existed"})
          return
        }
        updateCurrentUser(res.data)
        toast.success("Successfully creatred account", {autoClose: 1500})
        if(res.data.role === 'student')
          navigate('/student')
        else
          navigate('/tas/queries')
      })
      .catch(error => {
        toast.error(error.message, {autoClose: 1500})
      }
      )
    }
    // setErrors(validationResponse);
  }
   
  return (
    <div className='account shadow-lg p-3 mb-5 bg-body py-3'>
      <h1 className='mb-3 text-center'> SignUp </h1>
      <Form className='mx-3 '>
        <TextInput
          onChange = {event => setData({...data, name: event.target.value})}
          onFocus = {() => setErrors(prevErrors => ({...prevErrors, name: ''}))}
          type = "text" 
          label = "Full Name" 
          id = "fullname" 
          placeholder = "Full Name" 
          className = "form-control" 
          name = "fullname"
          errors = { errors.name }
          required = {true}
        />
        <TextInput
          onChange = {event => setData({...data, rollNumber: event.target.value})}
          onFocus = {() => setErrors(prevErrors => ({...prevErrors, rollNumber: ''}))}
          type = "number" 
          label = "Roll Number" 
          id = "rollnumber" 
          placeholder = "Roll Number" 
          className = "form-control" 
          name = "rollnumber"
          errors = { errors.rollNumber }
          required = {true}
        />
        <TextInput 
          onChange = {event => setData({...data, password: event.target.value})}
          onFocus = {() => setErrors(prevErrors => ({...prevErrors, password: ''}))}
          type = "password" 
          label = "Password" 
          id = "password" 
          placeholder = "Password" 
          className = "form-control" 
          name = "password"
          errors = { errors.password }
          required = {true}
        />
        <TextInput 
          onChange = {event => setData({...data, confirmPassword: event.target.value})}
          onFocus = {() => setErrors(prevErrors => ({...prevErrors, confirmPassword: ''}))}
          type = "password" 
          label = "Confirm Password" 
          id = "confirmPassword" 
          placeholder = "Confirm Password" 
          className = "form-control" 
          name = "confirmPassword"
          errors = { errors.confirmPassword }
          required = {true}
        />
        <SelectDrapdown 
          onChange = {event => setData({...data, role: event.target.value})}
          onFocus = {() => setErrors(prevErrors => ({...prevErrors, role: ''}))}
          label = "SignIn as" 
          id = "floatingSelect" 
          className = "" 
          name = "selectRole"
          values = {roles}
          errors = { errors.role }
        />
        <div className="button-group">
          <Button 
            value = 'SignUp'
            type='submit'
            className='btn-primary'
            onClick={event => handleSignUp(event)}
          />
          <Button 
            value = 'SignIn'
            type='button'
            className='btn-link'
            onClick={() =>navigate('/')}
          />
        </div>
      </Form>
    </div>
  )
}

export default SignUp