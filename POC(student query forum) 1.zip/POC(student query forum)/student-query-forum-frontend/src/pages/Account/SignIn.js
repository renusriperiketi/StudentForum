import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router';
import { toast } from 'react-toastify';
import { postData } from '../../config/backendAPI';
import { CurrentUserContext } from '../../lib/ContextAPI';
import TextInput from '../../lib/components/form/TextInput';
import SelectDrapdown from '../../lib/components/form/SelectDrapdown';
import Form from '../../lib/components/form/Form';
import Button from '../../lib/components/form/Button';
import { validateSignin } from '../validations';
import '../../lib/assets/stylesheets/pages/account/SignIn.css'

const SignIn = () => {

  const initialState = {
    rollNumber: '',
    password: '',
    role: 'student'
  }
  const roles = ['student', 'TA']
  const {updateCurrentUser} = useContext(CurrentUserContext)
  const navigate = useNavigate();
  const [state, setState] = useState(initialState);
  const [errors, setErrors] = useState({})

  const handleSignIn = async (event) => {
    event.preventDefault();
    let validationResponse = validateSignin(state)
    if(validationResponse === true)
    {
      const loginData = {
        roll_number: state.rollNumber,
        role: state.role,
        password: state.password
      }
      postData('signin', loginData)
      .then(res =>  {
        let response = res.data
        if(response.user?.id){
          localStorage.setItem('token', response.token )
          localStorage.setItem('userId', response.user.id )
          updateCurrentUser(response.user)
          toast.success('Succesfully loggedin!', {autoClose: 5000})
          if(response.user.role === 'student')
          {
            navigate('/student')
          }
          else
            navigate('/tas/queries')
          setState(initialState)
        }
        else if(response.message === 'password'){
          setErrors({
            password: 'incorrect password'
          })
        }
        else if (response.message === 'role'){
          setErrors({
            role: 'role not matched'
          })
        }
        else
        {
          setErrors({
            rollNumber: 'invalid rollnumber',
          })
        }
      })
      .catch(error => {
        toast.error(error.message, {autoClose: 1500})
        })
    }
    setErrors(validationResponse);

  }
  return (
    <div className='account shadow-lg p-3 mb-5 bg-body rounded py-3'>
        <h1 className='mb-3 text-center'> SignIn </h1>
        <Form className='mx-3 '>
          <TextInput 
            onChange = {event => setState({...state, rollNumber: event.target.value})}
            onFocus = {() => setErrors(prevErrors => ({...prevErrors, rollNumber:''}))}
            value = {state.rollNumber}
            type = "number" 
            label = "Roll Number" 
            id = "rollnumber" 
            placeholder = "Roll Number" 
            className = "form-control" 
            name = "rollnumber"
            errors = { errors.rollNumber }
            required = {true}
          />
          <TextInput 
            onChange = {event => setState({...state, password: event.target.value})}
            onFocus = {() => setErrors(prevErrors => ({...prevErrors, password: ''}))}
            value = {state.password}
            type = "password" 
            label = "Password" 
            id = "password" 
            placeholder = "Password" 
            className = "form-control" 
            name = "password"
            errors = { errors.password }
            required = {true}
          />
          <SelectDrapdown 
            onChange = {event => setState({...state, role: event.target.value})}
            onFocus = {() => setErrors(prevErrors => ({...prevErrors, role: ''}))}
            label = "SignIn as" 
            id = "floatingSelect" 
            className = "" 
            name = "selectRole"
            values = {roles}
            errors = { errors.role }
          />
          <div className="button-group">
            <Button 
              value = 'SignIn'
              type='submit'
              className='btn-primary'
              onClick={event => handleSignIn(event)}
            />
            <Button 
              value = 'SignUp'
              type='button'
              className='btn-link'
              onClick={() =>navigate('signup')}
            />
          </div>
        </Form>
    </div>
  )
}

export default SignIn