import React, { useState } from 'react'
import NewResponse from './NewResponse'

const StudentConcern = ({query}) => {
  const [isResponded, setIsResponded] = useState(query.response? true : false)
  const [response, setResponse] = useState('')
  const updateState = {
    setIsResponded,
    setResponse,
  }
  return (
    <div className='student-concern shadow mb-4 rounded'>
      <div className='student-concern-content my-4'>
        <div className='m-3'>
          <div className='mb-3'> 
            <div className='mb-3'>
              <span className='mx-2 fw-bold'>
                Student Roll Number:
              </span>
              <span className='mx-2'>
                {query.student_roll_number}
              </span> 
            </div>
            <div className='mb-3 '>
              <span className='mx-2 fw-bold'>
                Course Name:
              </span>
              <span className='mx-2'>
                {query.course_name}
              </span>
            </div>
            <div className='mb-3'>
              <span className='mx-2 fw-bold'>
                Question No:
              </span >
              <span className='mx-2'>
                {query.question_number}
              </span>
            </div>
          </div>
          <div className='student-concern-body'> 
            <div className='mb-4'>
              <div className='mx-2 fw-bold'>
                Student's Comments:
              </div>
              <div className='comment shadow p-2 m-2'>
                  <p>{query.comments}</p>
              </div>
            </div>
            {
              isResponded?
              <div className='mb-4'>
                <div className='mx-2 fw-bold'>
                  Your Response:
                </div>
                <div className='comment shadow p-2 m-2'>
                  <p>{query.response?query.response:response}</p>
                </div>
              </div>
              :<NewResponse query = {query} updateState = {updateState}/>
            }
          </div> 
        </div>
      </div>
    </div>
  )
}

export default StudentConcern