import React, { useContext, useEffect, useState } from 'react'
import { getData } from '../../config/backendAPI'
import DataNotPresent from '../../lib/components/DataNotPresent'
import { CurrentUserContext } from '../../lib/ContextAPI'
import StudentConcern from './StudentConcern'
import '../../lib/assets/stylesheets/pages/TAs/StudentConcerns.css'
import StudentQueries from './StudentQueries'

const TAsDashboard = () => {
   const initialFilter = {
    responded: false,
    notResponded: false,
  }
  const {currentUser} = useContext(CurrentUserContext)
  const [filter, setFilter] = useState(initialFilter)
  const [studentQueries, setStudentMyQueries] = useState([])
  const respondedQuries = studentQueries.filter(query => query.response )
  const notRespondedQuries = studentQueries.filter(query => !query.response )

  useEffect(() => {
    const queryParams = {
      roll_number: currentUser.roll_number,
      role: currentUser.role
    };
    getData('queries', queryParams)
    .then(res => {
      setStudentMyQueries(res.data)
    })
    .catch(error => console.log(error))
  }, [])

  const handleFilter = event => {
    console.log(event.target.value)
    if(event.target.name === "responded")
      event.target.value === 'true' ? 
      setFilter(prevFilter=>({...prevFilter, responded: false}))
      :
      setFilter(prevFilter=>({...prevFilter, responded: true}))

    else 
      event.target.value === 'true' ? 
      setFilter(prevFilter=>({...prevFilter, notResponded: false}))
      :
      setFilter(prevFilter=>({...prevFilter, notResponded: true}))
  }

  return (
    <div className='student-concerns mt-5'>
      <div className='d-flex justify-content-around align-items-center mt-5'>
        <div>
          <h1 >Students Concerns</h1>
        </div>
        <div className='d-flex justify-content-evenly'>
          <div className = "form-check form-switch">
            <input className = "form-check-input" 
            type="checkbox" id="responded"
            name='responded'
            value={filter.responded} 
            onClick = {event =>handleFilter(event)} />
            <label className = "form-check-label" htmlFor="responded">Responded</label>
          </div>
          <div className = "ms-5 form-check form-switch">
            <input className = "form-check-input" 
            type="checkbox" id="not-responded" 
            name='notResponded'
            value={filter.notResponded} 
            onClick = {event =>handleFilter(event)} />
            <label className = "form-check-label" htmlFor="not-responded">Not Responded</label>
          </div>
        </div>
      </div>
      { 
        studentQueries.length === 0 ? <DataNotPresent message={"No Students Concerns yet"} />:
        <>
        {
            !(filter.responded ^ filter.notResponded) ?
              // studentQueries.map(query => <StudentConcern key={query.id} query={query}/> )
              <StudentQueries studentQueries = {studentQueries} />
              :
              filter.responded?
                <StudentQueries studentQueries = {respondedQuries} />
                // respondedQuries.map(query => <StudentConcern key={query.id} query={query}/> )
                :
                <StudentQueries studentQueries = {notRespondedQuries} />
                // notRespondedQuries.map(query => <StudentConcern key={query.id} query={query}/> )
          }
        </>
      }
    </div>
  )
}

export default TAsDashboard