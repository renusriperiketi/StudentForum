import React, { useState } from 'react'
import Pagination from '../../lib/components/pagination/pagination';
import CurrentPageQueries from './CurrentPageQueries';

const StudentQueries = ({studentQueries}) => {
  const queries = studentQueries;
  const [currentPage, setCurrentPage] = useState(1);
  const [queriesPerPage] = useState(2);

  const paginate = pageNumber => setCurrentPage(pageNumber);

  const indexOfLastQuery = currentPage * queriesPerPage;
  const indexOfFirstQuery = indexOfLastQuery - queriesPerPage;
  const currentQueries = queries.slice(indexOfFirstQuery, indexOfLastQuery);

  return( 
    <>
      <CurrentPageQueries currentQueries = {currentQueries} paginate = {paginate} />
      <Pagination itemsPerPage={queriesPerPage} totalItems={queries.length} paginate = {paginate} currentPage = {currentPage}/>
    </>
  )
}

export default StudentQueries