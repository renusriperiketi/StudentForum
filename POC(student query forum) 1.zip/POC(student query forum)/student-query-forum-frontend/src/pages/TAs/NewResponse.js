import React, { useState } from 'react'
import { toast } from 'react-toastify'
import { updateData } from '../../config/backendAPI'
import { validateText } from '../../utils/validaters'

const NewResponse = ({query, updateState}) => {
  
  const [response, setResponse] = useState('')
  const [error, setError] = useState('')
  
  const postResponse = () => {
    const validationResponse = validateText(response)
    if(validationResponse !== true)
    {
      setError(validationResponse)
      return
    }
    if(!window.confirm(`Your Respose: ${response}`))
      return
    const data = {
      id: query.id,
      response: response
    }
    const URL = `queries/${data.id}`
    updateData(URL, data)
    .then(res => 
    {
      updateState.setIsResponded(true)
      updateState.setResponse(response)
      toast.success("Response posted successfully", {autoClose: 1500})
    })
    .catch(error => console.log(error))
  }

  return (
    <>
      <div className='mb-4'>
        <div className='mx-2 fw-bold'>
          Your Response:
        </div>
        <div className='ta-input-response m-2'>
          <textarea type='text' onChange={e => setResponse(e.target.value)} placeholder = 'Enter your Response'/>
          <p className='text-danger'>{error}</p>
        </div>
      </div>
      <button className='btn btn-primary mt-4' onClick={postResponse}>Post Response</button>
    </>
  )
}

export default NewResponse