import React, { useEffect } from 'react'
import StudentConcern from './StudentConcern'

const CurrentPageQueries = ({currentQueries, paginate}) => {

  useEffect(() => {
    if(currentQueries.length === 0)
    paginate(1)
  })

  return currentQueries.map(query => <StudentConcern key={query.id} query={query}/>)
}
export default CurrentPageQueries

