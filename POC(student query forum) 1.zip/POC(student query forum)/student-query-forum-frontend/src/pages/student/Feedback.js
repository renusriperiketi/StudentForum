import React from 'react'

const Feedback = ({query}) => {
  
  return (
    <div className='feedback shadow mb-4 rounded'>
      <div className='feedback-content my-4'>
        <div className='m-3'>
          <div className='feedback-head'>
            <div className='mb-3'>
              <span className='mx-2 fw-bold'>
                Exam Name:
              </span>
              <span className='mx-2'>
                {query.exam_name}
              </span>
            </div>
            <div className='mb-3 '>
              <span className='mx-2 fw-bold'>
                Course Name:
              </span>
              <span className='mx-2'>
                {query.course_name}
              </span>
            </div>
            <div className='mb-3'>
              <span className='mx-2 fw-bold'>
                Question No:
              </span >
              <span className='mx-2'>
                {query.question_number}
              </span>
            </div>
            <div className='mb-3'>
              
              <span className='mx-2 fw-bold'>
                TA's Roll Number:
              </span>
              <span className='mx-2'>
                {query.ta_roll_number}
              </span>
            </div>
          </div>
          <div className='feedback-body'> 
            <div className='mb-4'>
              <div className='mx-2 fw-bold'>
                Your Comments:
              </div>
              <div className='shadow p-2 mb-2 comment mx-2'>
                <p>{query.comments}</p>
              </div>
            </div>
            <div className='mb-4'>
              <div className='mx-2 fw-bold'>
                TA's Response:
              </div>
              <div className='shadow p-2 mb-2 comment mx-2'>
                {
                  query.response?
                  <p>{query.response}</p>:
                  <p className='text-danger'>Not Responded</p>
                }
              </div>
            </div>
          </div>  
        </div>
      </div>
    </div>
  )
}

export default Feedback