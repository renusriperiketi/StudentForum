import React, { useContext, useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { toast } from 'react-toastify'
import { getData, postData } from '../../config/backendAPI'
import '../../lib/assets/stylesheets/pages/student/addNewQuery.css'
import { CurrentUserContext } from '../../lib/ContextAPI'
import { validateStudentQueryForm } from '../validations'

const AddNewQuery = () => {
  const initialState = {
    examName: '',
    courseName: '',
    questionNumber:'',
    taName: '',
    comments: ''
  }
  const {currentUser} = useContext(CurrentUserContext)
  const navigate = useNavigate()
  const [state, setState] = useState(initialState)
  const [TAs, setTAs] = useState([])
  const [errors, setErrors] = useState({})
   
  useEffect(() => {
    getData('users')
    .then(res => {
      setTAs(res.data.filter(user => user.role === "TA"))
  })
    .catch(error => console.log(error))
  }, [])

  const handleSubmit = event => {
    event.preventDefault();
    let validationResponse = validateStudentQueryForm(state)
    
    if(validationResponse === true)
    {
      const data = {
        exam_name: state.examName,
        course_name: state.courseName,
        question_number: state.questionNumber,
        ta_roll_number: state.taName,
        student_roll_number: currentUser.roll_number,
        comments: state.comments,
        commented_at: new Date(),
        responded_at: null
      }
      postData('queries', data)
      .then(res => 
      {
        toast.success("Your comments posted successfully", {autoClose: 1500})
        navigate('/student')
      })
      .catch(error => console.log(error))
    }
    else{
      setErrors(validationResponse)
    }
  }

  return (
    <div className='add-new-query shadow-lg p-3 mb-5 bg-body py-3'>
      <h1 className='text-center'>Query Form</h1>
      <form className='text-center mx-3'>
        <div className ="row mb-3">
          <label htmlFor  ="examName" className ="col-sm-2 col-form-label">Exam Name :</label>
          <div className ="col-sm-10">
            <input type="text" className ="form-control" id="examName" 
              onChange={(event) => setState({...state, examName: event.target.value})}
              onFocus = {() => setErrors(prevErrors => ({...prevErrors, examName: ''}))}/>
            <p className='text-danger'>{errors.examName}</p>
            
          </div>
        </div>
        <div className ="row mb-3">
          <label htmlFor  ="courseName" className ="col-sm-2 col-form-label">Course Name :</label>
          <div className ="col-sm-10">
            <input type="text" className ="form-control" id="courseName"
              onChange={(event) => setState({...state, courseName: event.target.value})}
              onFocus = {() => setErrors(prevErrors => ({...prevErrors, courseName: ''}))}/>
            <p className='text-danger'>{errors.courseName}</p>

          </div>
        </div>
        <div className ="row mb-3">
          <label htmlFor  ="questionNumber" className ="col-sm-2 col-form-label">Question No :</label>
          <div className ="col-sm-10">
            <input type="text" className ="form-control" id="questionNumber"
              onChange={(event) => setState({...state, questionNumber: event.target.value})}
              onFocus = {() => setErrors(prevErrors => ({...prevErrors, questionNumber: ''}))}/>
            <p className='text-danger'>{errors.questionNumber}</p>

          </div>
        </div>
        <div className ="row mb-3">
          <label htmlFor  ="taName" className ="col-sm-2 col-form-label"> TA's Name :</label>
          <div className ="col-sm-10">
            <select className  = "form-select" defaultValue = "student" id="floatingSelect" aria-label="Floating label select example"
              onChange={(event) => setState({...state, taName: event.target.value})}
              onFocus = {() => setErrors(prevErrors => ({...prevErrors, taName: ''}))}>
                <option value = "">select</option>
                {
                  TAs.map(ta => (
                    <option key={ta.id} value={ta.roll_number}>{`${ta.full_name}(${ta.roll_number})`}</option>
                  ))
                }
            </select>
            <p className='text-danger'>{errors.taName}</p>
          </div>
        </div>
        <div className ="row mb-3">
          <label htmlFor  ="comments" className ="col-sm-2 col-form-label">Comments :</label>
          <div className ="col-sm-10">
            <textarea type="textarea" className ="form-control" id="comments" 
              onChange={(event) => setState({...state, comments: event.target.value})}
              onFocus = {() => setErrors(prevErrors => ({...prevErrors, comments: ''}))}/>
            <p className='text-danger'>{errors.comments}</p>
          </div>
        </div>
        <div>
          <button type='submit' className='btn btn-primary px-5' onClick={event => handleSubmit(event)}>Post Query</button>
        </div>
      </form>
    </div>
  )
}

export default AddNewQuery