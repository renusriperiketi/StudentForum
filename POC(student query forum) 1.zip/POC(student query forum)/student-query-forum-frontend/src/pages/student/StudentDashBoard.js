import React, { useContext, useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { getData } from '../../config/backendAPI'
import DataNotPresent from '../../lib/components/DataNotPresent'
import { CurrentUserContext } from '../../lib/ContextAPI'
import '../../lib/assets/stylesheets/pages/student/feedbacks.css'
import MyQueries from './MyQueries'


 
const StudentDashBoard = () => {

  const initialFilter = {
    responded: false,
    notResponded: false,
  }
  const {currentUser} = useContext(CurrentUserContext)
  const [myQuerirs, setMyQueries] = useState([])
  const [filter, setFilter] = useState(initialFilter)
  const navigate = useNavigate();
  const notRespondedQuries = myQuerirs.filter(query => !query.response )
  let respondedQuries = myQuerirs.filter(query => query.response )
  
  const sortByLatestResponses = array => {
    array.sort(function(a, b){
      return new Date(a.updated_at) - new Date(b.updated_at);
    });
    return array;
  }
  respondedQuries = !respondedQuries.length?respondedQuries : sortByLatestResponses(respondedQuries)
  
  useEffect(() => {
    const queryParams = {
      roll_number: currentUser.roll_number,
      role: currentUser.role,
    };
    getData('queries', queryParams)
    .then(res => {
      setMyQueries(res.data)
    })
    .catch(error => console.log(error))
  }, [])

  const handleFilter = event => {
    console.log(event.target.value)
    if(event.target.name === "responded")
      event.target.value === 'true' ? 
      setFilter(prevFilter=>({...prevFilter, responded: false}))
      :
      setFilter(prevFilter=>({...prevFilter, responded: true}))

    else 
      event.target.value === 'true' ? 
      setFilter(prevFilter=>({...prevFilter, notResponded: false}))
      :
      setFilter(prevFilter=>({...prevFilter, notResponded: true}))
  }

  return (
    <div className='feedbacks'>
      <div className='d-flex justify-content-between align-items-center mt-5'>
        <div className=' '>
          <h1 >Feedbacks</h1>
        </div>
        <div className='d-flex justify-content-evenly'>
          <div className = "form-check form-switch">
            <input 
              className = "form-check-input" 
              type="checkbox" name='responded' 
              value={filter.responded} 
              onClick = {event =>handleFilter(event)} id="responded"/>
            <label className = "form-check-label" htmlFor="responded">Responded</label>
          </div>
          <div className = "ms-5 form-check form-switch">
            <input 
              className = "form-check-input" 
              type="checkbox" name='notResponded' 
              value={filter.notResponded} 
              onClick = {event =>handleFilter(event)} id="not-responded" />
            <label className = "form-check-label" htmlFor="not-responded">Not Responded</label>
          </div>
        </div>
        <div className=''>
          <button type = 'button' onClick={() => navigate('addQuery')} className='btn btn-primary'>New Query</button>
        </div>
      </div>
      {
        myQuerirs.length === 0 ? <DataNotPresent message={"No Queries yet"} />:
        <>
          {
            !(filter.responded ^ filter.notResponded) ?
              <MyQueries myQueries={myQuerirs}/>
              // myQuerirs.map(query => <Feedback key={query.id} query={query}/> )
              :
              filter.responded?
                <MyQueries myQueries={respondedQuries}/>
                // respondedQuries.map(query => <Feedback key={query.id} query={query}/> )
                :
                <MyQueries myQueries={notRespondedQuries}/>
                // notRespondedQuries.map(query => <Feedback key={query.id} query={query}/> )
          }
        </>
      }
    </div>
  )
}

export default StudentDashBoard