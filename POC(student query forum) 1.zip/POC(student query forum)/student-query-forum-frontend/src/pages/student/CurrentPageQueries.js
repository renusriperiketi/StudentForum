import React, { useEffect } from 'react'
import Feedback from './Feedback'

const CurrentPageQueries = ({currentQueries, paginate}) => {
  useEffect(() => {
    if(currentQueries.length === 0)
    paginate(1)
  })
  return currentQueries.map(query => <Feedback key={query.id} query={query}/>)
}
export default CurrentPageQueries
