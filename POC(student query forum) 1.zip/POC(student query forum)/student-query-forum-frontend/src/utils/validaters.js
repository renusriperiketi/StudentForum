const validateName = name => {
  if(name.trim().length === 0)
    return 'must enter'
  return ''
}

const validateRollNumber = rollNumber => {
  const roll = rollNumber.trim();
  if(roll.length === 0)
    return 'must enter'
  let errors = ''
  if(roll.length !== 10)
    errors += 'length should be 10 characters'
  if(!roll.match(/[0-9]+$/))
    errors += 'Only Numbers'
  return errors?errors:''
}

const validatePassword = password => {
  const psword = password.trim();
  let errors = ''
  if(psword.length === 0)
    return 'must enter'
  if(psword.length < 6)
    errors += 'length atleast 6 characters,'
  if(!psword.match(/[a-z]+/))
    errors += ' should have atleast one lowercase letter,'
  if(!psword.match(/[A-Z]+/))
    errors += ' should have atleast one uppercase letter,'
  if(!psword.match(/[0-9]+/))
    errors += ' should have atleast one digit,'
  if(!psword.match(/[^a-zA-Z0-9]+/))
    errors += ' should have atleast one special character,'
  return errors?errors: ''
}

const validateConfirmPassword = (password, confirmPassword) => {
  if(password.trim() !== confirmPassword.trim())  
    return 'password not matched'
  return ''
}

const validateNumber = number => {
  if(!number.match(/[0-9]+/))
    return "not a number"
  return ''
}

const validateText = text => {
  if(!text.length)
    return "must enter"
  if(text.length < 10)
    return "minimum 10 characters"
  return ''
}
 export { 
  validateName, 
  validateRollNumber, 
  validatePassword, 
  validateConfirmPassword, 
  validateNumber, 
  validateText 
}