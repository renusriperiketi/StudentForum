import React, { useContext } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { FaUser } from 'react-icons/fa';
import { CurrentUserContext } from '../lib/ContextAPI'
import '../lib/assets/stylesheets/headers/NavBar.css'
import _ from 'underscore';

const NavBar = () => {
  const navigate = useNavigate()
  const {currentUser, updateCurrentUser} = useContext(CurrentUserContext)
  const handleSignout = () => {
    updateCurrentUser(null)
    localStorage.clear()
    navigate('/')
  }
  return (
    <div className='nav-bar'> 
      <ul className='left-nav'>
        <li>
        {
          !_.isEmpty(currentUser)?
            currentUser.role === 'student' ?
              <NavLink to='/student'>My Querirs</NavLink>:
              <NavLink to='/tas/queries'>Students Concerns</NavLink>
            :''
        }
        </li>
      </ul>
      <ul>
        <span className='badge text-wrap header-title'>
          ABC Schools  
        </span>
      </ul>
      <ul className='right-nav'>
        {
          !_.isEmpty(currentUser)?
          <li className='px-2 user-account'>
            <div>
              <FaUser />
              <span className='ms-2'>{currentUser.full_name}</span>
            </div> 
            <span className='account-dropdown'>
              <Link  onClick={handleSignout}>Sign Out</Link>
            </span>
          </li>
          :
          <>
            <li className='user-account'>
              <div><FaUser /><span className='ms-2'>Account</span></div>
                <span className='account-dropdown'>
                  <Link to="/">Signin</Link>
                  <Link to="/signup"> SignUp</Link>
                </span>
            </li>
          </>
        }
      </ul>
    </div>
  )
}

export default NavBar