import {rest} from "msw";
import { BASE_URL } from "../../config/backendAPI";

export const handlers = [
  rest.post(`${BASE_URL}signin`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json(
        {
          user: {
            id: 123,
            rollNumber: '9876543210',
            password: 'User1@1234',
            role: 'student',
          },
          token: 'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJleHAiOjE2ODMzNjgxMTh9.KoE2c6u6C-s45tDrTYoiopfM21dWn71IudKPsU0R0ok',
        }
      )
    )
  })
]