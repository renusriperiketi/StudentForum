import { screen, render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import NavBar from "../../headers/NavBar";
import { CurrentUserContext } from "../../lib/ContextAPI";
import React from "react";

describe('NavBar', () => {
  describe('when user not logged in', () => {
    test('should render correctly', () => {
      render(<NavBar/>, {wrapper: BrowserRouter})
      expect(screen.getByText(/abc schools/i)).toBeInTheDocument()
      const signinLink = screen.getByRole('link', {
        name: /signin/i
      })
      const signupLink = screen.getByRole('link', {
        name: /signup/i
      })
      expect(signinLink).toBeInTheDocument()
      expect(signupLink).toBeInTheDocument()
    })
  })
  describe('when user logged in', () => {
    test('should render student dashboard navbar', () => {
      const mockStudent = {
        id: 1,
        full_name: 'Student1',
        role: 'student'
      }
      render(
        <BrowserRouter>
          <CurrentUserContext.Provider value={{currentUser: mockStudent}}>
            <NavBar/>
          </CurrentUserContext.Provider>
        </BrowserRouter>
        )
      expect(screen.getByText(/abc schools/i)).toBeInTheDocument()
      expect(screen.getByRole('link', {
        name: /my querirs/i
      })).toBeInTheDocument()
      expect(screen.getByText(/student1/i)).toBeInTheDocument()
      expect(screen.getByRole('link', {
        name: /sign out/i
      })).toBeInTheDocument()
    })
    test('should render ta dashboard navbar', () => {
      const mockStudent = {
        id: 1,
        full_name: 'TA1',
        role: 'ta'
      }
      render(
        <BrowserRouter>
          <CurrentUserContext.Provider value={{currentUser: mockStudent}}>
            <NavBar/>
          </CurrentUserContext.Provider>
        </BrowserRouter>
        )
      expect(screen.getByText(/abc schools/i)).toBeInTheDocument()
      expect(screen.getByRole('link', {
        name: /students concerns/i
      })).toBeInTheDocument()
      expect(screen.getByText(/ta1/i)).toBeInTheDocument()
      expect(screen.getByRole('link', {
        name: /sign out/i
      })).toBeInTheDocument()
    })
  })
})