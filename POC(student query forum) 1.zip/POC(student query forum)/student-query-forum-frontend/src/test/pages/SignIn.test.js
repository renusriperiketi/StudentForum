/* eslint-disable testing-library/no-unnecessary-act */
import { screen, render, act } from "@testing-library/react";
import { rest } from "msw";
import { BrowserRouter, MemoryRouter, Router } from "react-router-dom";
import { BASE_URL } from "../../config/backendAPI";
import SignIn from "../../pages/Account/SignIn";
import { server } from "../mocks/server";
import user from '@testing-library/user-event'

describe("SignIn", () => {
  const studentFormData = {
    rollNumber: '9876543210',
    password: 'User1@1234',
    role: 'student',
  }

  test('Should render correctly', () => {
    user.setup();
    render(<SignIn />, {wrapper: BrowserRouter})

    const signinHeading = screen.getByRole('heading', {
        name: /signin/i
      })
    expect(signinHeading).toBeInTheDocument(); 

    const rollNumberLabel = screen.getByText(/roll number/i)
    expect(rollNumberLabel).toBeInTheDocument()

    const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
    expect(rollNumberInput).toBeInTheDocument()

    const passwordLabel = screen.getByText(/password/i)
    expect(passwordLabel).toBeInTheDocument()

    const passwordInput = screen.getByLabelText(/password\*/i)
    expect(passwordInput).toBeInTheDocument()

    const selectRoleLabel = screen.getByText(/signin as/i)
    expect(selectRoleLabel).toBeInTheDocument()

    const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
    expect(selectDrapdown).toBeInTheDocument()

    const signinButton = screen.getByRole('button', {
      name: /signin/i
    })
    expect(signinButton).toBeInTheDocument()

    const signupButton = screen.getByRole('button', {
      name: /signup/i
    })
    expect(signupButton).toBeInTheDocument()
  })

  describe('On successful signin', () => {
    test('signin should success',  async () => {
      render(<SignIn />, {wrapper: BrowserRouter})
      user.setup();
      const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
      const passwordInput = screen.getByLabelText(/password\*/i)
      const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
      await act( async () => user.type(rollNumberInput, studentFormData.rollNumber))
      await act(() => user.type(passwordInput, studentFormData.password))
      await act (() =>user.type(selectDrapdown, studentFormData.role))
      
      const signinButton = screen.getByRole('button', {
        name: 'SignIn'
      })
      await act(() => user.click(signinButton));
    })
  })

  describe('When validations failed', () => {
    test('invalid rollnumber', async () => {
      render(<SignIn />, {wrapper: BrowserRouter})
      user.setup();
      const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
      const passwordInput = screen.getByLabelText(/password\*/i)
      const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
      await act(() => user.type(rollNumberInput, " " ))
      await act(() => user.type(passwordInput, studentFormData.password))
      await act (() =>user.type(selectDrapdown, studentFormData.role))
      
      const signinButton = screen.getByRole('button', {
        name: 'SignIn'
      })
      await act(() => user.click(signinButton));
      const rollNumberMustEnterMessage = await screen.findByText('must enter')
      expect(rollNumberMustEnterMessage).toBeInTheDocument()

      await act(() => user.type(rollNumberInput, "12345" ))
      await act(() => user.click(signinButton));

      const rollNumberLengthMessage = await screen.findByText('length should be 10 characters')
      expect(rollNumberLengthMessage).toBeInTheDocument()
    });

    test('invalid password', async () => {
      render(<SignIn />, {wrapper: BrowserRouter})
      user.setup();
      const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
      const passwordInput = screen.getByLabelText(/password\*/i)
      const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
      await act(() => user.type(rollNumberInput, studentFormData.rollNumber ))
      await act(() => user.type(passwordInput, ' ' ))
      await act (() =>user.type(selectDrapdown, studentFormData.role))
      
      const signinButton = screen.getByRole('button', {
        name: 'SignIn'
      })
      await act(() => user.click(signinButton));
      const passwordMustEnterMessage = await screen.findByText('must enter')
      expect(passwordMustEnterMessage).toBeInTheDocument()

      await act(() => user.clear(passwordInput))
      await act(() => user.type(passwordInput, "Ab@12" ))
      await act(() => user.click(signinButton));
      const passwordLengthMessage = await screen.findByText(/length atleast 6 characters/i)
      expect(passwordLengthMessage).toBeInTheDocument()


      await act(() => user.clear(passwordInput))
      await act(() => user.type(passwordInput, "Abcd1234"))
      await act(() => user.click(signinButton));
      const passwordSpecialCharacterMessage = await screen.findByText(/should have atleast one special character/i)
      expect(passwordSpecialCharacterMessage).toBeInTheDocument()

      await act(() => user.clear(passwordInput))
      await act(() => user.type(passwordInput, "abc@12" ))
      await act(() => user.click(signinButton));
      const passwordUppercaseLetterMessage = await screen.findByText(/should have atleast one uppercase letter/i)
      expect(passwordUppercaseLetterMessage).toBeInTheDocument()

      await act(() => user.clear(passwordInput))
      await act(() => user.type(passwordInput, "ABC@12" ))
      await act(() => user.click(signinButton));
      const passwordLowercaseLetterMessage = await screen.findByText(/should have atleast one lowercase letter/i)
      expect(passwordLowercaseLetterMessage).toBeInTheDocument()

      await act(() => user.clear(passwordInput))
      await act(() => user.type(passwordInput, "ABC@ef" ))
      await act(() => user.click(signinButton));
      const passwordNumberMessage = await screen.findByText(/should have atleast one digit/i)
      expect(passwordNumberMessage).toBeInTheDocument()
    })
  })

  describe('When invalid credentials', () => {
    test('should render incorrect password error message',  async () => {
      server.use(
        rest.post(`${BASE_URL}signin`, (req, res, ctx) => {
          return res(
            ctx.status(200),
              ctx.json(
              {
                message: 'password'
              }
            )
          )
        })
      )
      render(<SignIn />, {wrapper: BrowserRouter})
      user.setup();
      const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
      const passwordInput = screen.getByLabelText(/password\*/i)
      const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
      await act( () => user.type(rollNumberInput, studentFormData.rollNumber))
      await act(() => user.type(passwordInput, studentFormData.password))
      await act (() =>user.type(selectDrapdown, studentFormData.role))
      const signinButton = screen.getByRole('button', {
        name: 'SignIn'
      })
      await act(() => user.click(signinButton));
    })

    test('should render invalid rollnumber error message',  async () => {
      server.use(
        rest.post(`${BASE_URL}signin`, (req, res, ctx) => {
          return res(
            ctx.status(200),
              ctx.json(
              {
                message: 'rollnumber'
              }
            )
          )
        })
      )
      render(<SignIn />, {wrapper: BrowserRouter})
      user.setup();
      const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
      const passwordInput = screen.getByLabelText(/password\*/i)
      const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
      await act(() => user.type(rollNumberInput, studentFormData.rollNumber))
      await act(() => user.type(passwordInput, studentFormData.password))
      await act (() =>user.type(selectDrapdown, studentFormData.role))
      
      const signinButton = screen.getByRole('button', {
        name: 'SignIn'
      })
      await act(() => user.click(signinButton));
      const passwordErrorMessage = await screen.findByText(/invalid rollnumber/i)
      expect(passwordErrorMessage).toBeInTheDocument()
    })
    test('should render role not matched error message',  async () => {
      server.use(
        rest.post(`${BASE_URL}signin`, (req, res, ctx) => {
          return res(
            ctx.status(200),
              ctx.json(
              {
                message: 'role'
              }
            )
          )
        })
      )
      render(<SignIn />, {wrapper: BrowserRouter})
      user.setup();
      const rollNumberInput = screen.getByRole('spinbutton', {
        name: /roll number/i
      })
      const passwordInput = screen.getByLabelText(/password\*/i)
      const selectDrapdown = screen.getByRole('combobox', {
        name: /signin as/i
      })
      await act( async () => user.type(rollNumberInput, studentFormData.rollNumber))
      await act(() => user.type(passwordInput, studentFormData.password))
      await act (() =>user.type(selectDrapdown, studentFormData.role))
      
      const signinButton = screen.getByRole('button', {
        name: 'SignIn'
      })
      user.click(signinButton)
      const passwordErrorMessage = await screen.findByText(/role not matched/i)
      expect(passwordErrorMessage).toBeInTheDocument()
    })
  })
  test.todo('should render signup page on button click')
})