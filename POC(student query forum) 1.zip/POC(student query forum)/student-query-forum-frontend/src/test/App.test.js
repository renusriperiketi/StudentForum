import { screen, render, findByRole, act } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import App from "../App";
import user from '@testing-library/user-event'

describe('App', () => { 
  describe('when user not logged in', () => {
    test('should render correctly and by default render signin page', () => {
      render(<App />, {wrapper: BrowserRouter})
      expect(screen.getByText(/abc schools/i)).toBeInTheDocument()
      expect(screen.getByText(/account/i)).toBeInTheDocument()
      const signinLink = screen.getByRole('link', {
        name: /signin/i
      })
      const signupLink = screen.getByRole('link', {
        name: /signup/i
      })
      expect(signinLink).toBeInTheDocument()
      expect(signupLink).toBeInTheDocument()
      expect(screen.getByRole('heading', {name: 'SignIn'})).toBeInTheDocument()
    })

    test('should navigate to particular location', async () => {
      user.setup()
      render(<App />, {wrapper: BrowserRouter})
      const signinLink = screen.getByRole('link', {
        name: /signin/i
      })
      const signupLink = screen.getByRole('link', {
        name: /signup/i
      })
      expect(signinLink).toBeInTheDocument()
      expect(signupLink).toBeInTheDocument()
      await act(() => user.click(signinLink))
      const signinHeading = await screen.findByRole('heading', {name: 'SignIn'})
      expect(signinHeading).toBeInTheDocument()

      await act(() => user.click(signupLink))
      const signupHeading = await screen.findByRole('heading', {name: 'SignUp'})
      expect(signupHeading).toBeInTheDocument()
    })
  })  
  describe('when student logged in', () => {
    test.skip('should render correctly',() => {
      render(<App />, {wrapper: BrowserRouter})
      expect(screen.getByText(/abc schools/i)).toBeInTheDocument()
    })
  })
})