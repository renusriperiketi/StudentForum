import React, { useContext } from "react";
import { Outlet, Navigate } from "react-router-dom";
import { CurrentUserContext } from "../lib/ContextAPI";

const PrivateRoute = () => {
  const  {currentUser} = useContext(CurrentUserContext);
  return (
      currentUser?<Outlet />:<Navigate to='/' /> 
  )
};

export default PrivateRoute