import axios from "axios"
export const BASE_URL = 'http://localhost:4000/'

const setAuthToken = () => {
  const token = localStorage.getItem('token')
   if(token){
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
   }
   else
    delete axios.defaults.headers.common["Authorization"]
}


const postData = async (URL, data) => {
  
  return await axios.post(`${BASE_URL}${URL}`, data)
}

const getData = async (URL, params = {}) => {
  const config = {
    params
  }
  setAuthToken()
  return await axios.get(`${BASE_URL}${URL}`, config)
}

const updateData = async (URL, data) => {
  setAuthToken()
  return await axios.patch(`${BASE_URL}${URL}`, data)
}


export {postData, getData, updateData}