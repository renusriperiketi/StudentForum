class CreateQueries < ActiveRecord::Migration[7.0]
  def change
    create_table :queries do |t|
      t.string :course_name, null: false
      t.string :exam_name, null: false
      t.string :question_number, null: false
      t.text :comments, null: false
      t.datetime :commented_at, null: false
      t.datetime :responded_at
      t.string :student_roll_number, null: false
      t.string :ta_roll_number, null: false
      t.timestamps
    end
  end
end
