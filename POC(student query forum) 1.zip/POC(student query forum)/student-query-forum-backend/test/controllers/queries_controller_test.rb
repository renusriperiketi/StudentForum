require "test_helper"

class QueriesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @query = queries(:one)
  end

  test "should get index" do
    get queries_url, as: :json
    assert_response :success
  end

  test "should create query" do
    assert_difference("Query.count") do
      post queries_url, params: { query: { commented_at: @query.commented_at, comments: @query.comments, course_name: @query.course_name, exam_name: @query.exam_name, question_number: @query.question_number, responded_at: @query.responded_at, user_id: @query.user_id } }, as: :json
    end

    assert_response :created
  end

  test "should show query" do
    get query_url(@query), as: :json
    assert_response :success
  end

  test "should update query" do
    patch query_url(@query), params: { query: { commented_at: @query.commented_at, comments: @query.comments, course_name: @query.course_name, exam_name: @query.exam_name, question_number: @query.question_number, responded_at: @query.responded_at, user_id: @query.user_id } }, as: :json
    assert_response :success
  end

  test "should destroy query" do
    assert_difference("Query.count", -1) do
      delete query_url(@query), as: :json
    end

    assert_response :no_content
  end
end
