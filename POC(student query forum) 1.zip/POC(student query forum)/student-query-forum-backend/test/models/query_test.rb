require "test_helper"

class QueryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
