class SessionsController < ApplicationController
  def create
    @user = User.find_by(roll_number: params[:roll_number])
      if @user and @user.role == params[:role] 
        if @user.try(:authenticate, params[:password])
          token = JsonWebToken.encode(user_id: @user.id)
          time = Time.now + 24.hours.to_i
          render json: {token: token, exp: time.strftime("%m-%d-%Y %H:%M"), user: @user}
        elsif @user
          render json: { message: 'password' }
        end
      elsif @user
        render json: { message: 'role'}
      else
        render json: { message: 'rollnumber' } 
      end
  end

  def destroy
    
  end

end
