class QueriesController < ApplicationController
  before_action :authorize_request, only: %i[ show update destroy ]

  # GET /queries
  def index
    if(params[:role] == 'student')
      @queries = Query.where(student_roll_number: params[:roll_number])
    else
      @queries = Query.where(ta_roll_number: params[:roll_number])
    end
    render json: @queries
  end

  # GET /queries/1
  def show
    render json: @query
  end

  # POST /queries
  def create
    @query = Query.new(query_params)
    if @query.save
      render json: @query, status: :created, location: @query
    else
      render json: @query.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /queries/1
  def update
    @query = Query.find(params[:id])
    @query.response = params[:response]
    @query.responded_at = Date.new
    if @query.save
      render json: @query
    else
      render json: @query.errors, status: :unprocessable_entity
    end
  end

  # DELETE /queries/1
  def destroy
    @query.destroy
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    

    # Only allow a list of trusted parameters through.
    def query_params
      params.require(:query).permit(:course_name, :exam_name, :student_roll_number, :ta_roll_number, :question_number, :comments, :commented_at, :responded_at, :user_id)
    end
end
