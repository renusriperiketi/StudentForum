class Query < ApplicationRecord
   
end
